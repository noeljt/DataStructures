HOMEWORK 3: DYNAMIC TETRIS ARRAYS


NAME:  < Joseph Noel >


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

< Nathan Siviy
	cplusplus.com
	stackoverflow.com
	lecture notes
	kibo schaffer>

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  < 20 >



MISC. COMMENTS TO GRADER:  
In my own test cases I tested each peice as I made new rotations/shapes, 
and in different positions to ensure edge cases worked correctly.
I only changed one value each test to ensure the variable I wanted to check worked.
If it worked, I then ran dr.memory to ensure there were no memory errors.


