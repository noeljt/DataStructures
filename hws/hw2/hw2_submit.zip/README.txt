HOMEWORK 2: TENNIS CLASSES


NAME:  < Joseph Noel >


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

< Nathan Siviy
	stackoverflow.com
	cppreference.com
	cplusplus.com >

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  < 19 >



DESCRIPTION OF 3RD STATISTIC:
A "wasted effort" statistic, which compares how many games the person played, verse how many matches (how successful they were) they won overall.
The more games they played and the less they won matches, the more effort they spent with no reward.



RESULTS FROM 3RD STATISTIC:

MATCH STATISTICS
Player              W    L   percentage
Marcos Baghdatis    3    0        1.000
David Nalbandian    1    1        0.500
Danai Udomchoke     0    1        0.000
Ivan Ljubicic       0    1        0.000
Radek Stepanek      0    1        0.000

GAME STATISTICS
Player              W    L   percentage
David Nalbandian   49   44        0.527
Radek Stepanek     24   22        0.522
Marcos Baghdatis   73   69        0.514
Ivan Ljubicic      21   25        0.457
Danai Udomchoke    18   25        0.419

MOST WASTED EFFORT
Player             Games  Matches    Ratio
                  Played      Won
Ivan Ljubicic         46       0     0.000
Radek Stepanek        46       0     0.000
Danai Udomchoke       43       0     0.000
David Nalbandian      93       1     0.011
Marcos Baghdatis     142       3     0.021

==========================================

This used the sample_scores.txt provided with the assignment, and shows how even though Marcos played in 142 games, he didn't waste his effort because he won 3 matches.  Meanwhile, poor Ivan, Radek, and Danai played a handfull of games each, and all lost their first match.  They need to pick a new profession.

MISC. COMMENTS TO GRADER:

Hardest part of third stat: formatting headers on grid.


