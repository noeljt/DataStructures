HOMEWORK 1: MORPHOLOGICAL IMAGE PROCESSING


NAME:  < Joseph Noel >


COLLABORATORS AND OTHER RESOURCES:

< Stackoverflow
cplusplus.com 
Nathan Siviy>

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  < 7 >


EXTRA CREDIT:



MISC. COMMENTS TO GRADER:  
This was painful.
