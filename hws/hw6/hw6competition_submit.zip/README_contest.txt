HOMEWORK 6: CARCASSONNE CONTEST


NAME:  < Joseph Noel >



COLLABORATORS AND OTHER RESOURCES:
< Nathan Siviy, Zev Beigel, Joe Horne, cplusplus.com >



DESCRIPTION OF ANY PERFORMANCE IMPROVEMENTS/OPTIMIZATIONS:
None



DESCRIBE INTERESTING NEW PUZZLES YOU CREATED:
None :D


SUMMARY OF YOUR PERFORMANCE ON ALL PUZZLES:
Correctness & approximate wall clock running time for various command
line arguments.

I was told i was required to submit this... but I will be handing in homework late... so It's hard to test my not working program for run times :D

